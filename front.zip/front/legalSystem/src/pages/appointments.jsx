import * as React from 'react';
import '../App.css'
import App from '../App';

export default function Appointments()
{
    return (
    <>
     <div>
        <h1>Pendientes</h1>
     </div>
    </>
    )
}