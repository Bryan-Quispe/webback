import * as React from 'react';
import '../App.css'
import App from '../App';

export default function Dashboard()
{
    return (
    <>
     <div>
        <h1>Inicio</h1>
     </div>
    </>
    )
}
